/*
 * 
 * Kyle Brennan and Harrison Cunningham
 * CPSC 215
 * Dr. Jacob Sorber
 * Project 4 SimpleMail
 * 
 */
package cu.cs.cpsc215.project4;

public class MainDriver {

	public static void main(String[] args) {
		MainFrame client = new MainFrame();
		client.setVisible(true);
	}
	
}